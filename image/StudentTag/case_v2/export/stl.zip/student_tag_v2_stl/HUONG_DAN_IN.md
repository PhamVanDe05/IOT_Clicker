# Vỏ Student Tag V2: file in 3D và file CAD

Sinh bằng `export_v2.py` từ `student_tag_case_v2.scad`: sửa file `.scad` rồi chạy lại, không sửa tay các file ở đây.
Kích thước ngoài 55,9 × 85,9 × 33,45 mm.

## `stl/`: in 3D, một màu (cũng có trong `stl.zip` kèm file này)

16 file, mỗi file in 1 cái: vỏ trên, vỏ dưới, nắp pin (3 lẫy in liền), nắp USB (2 chốt in liền) và 12 phím.
12 phím khác nhau vì mỗi phím khắc một ký hiệu; 12 lỗ trên vỏ cùng cỡ, lắp phím theo ký hiệu:
`1 2 3 4 / 5 6 7 8 / ← 9 0 OK` (BACK là phím ←).

| File | Đặt khi in (đã xoay sẵn) | Nhựa (cm³, khối đặc) |
|---|---|---|
| `vo-tren.stl` | Mặt có chữ úp xuống bàn | 17,59 |
| `vo-duoi.stl` | Đáy xuống bàn | 17,86 |
| `nap-pin.stl` | Mặt ngoài xuống bàn, 3 lẫy hướng lên | 1,99 |
| `nap-usb.stl` | Mặt ngoài xuống bàn, 2 chốt hướng lên | 0,12 |
| `phim_1A.stl` | Mặt có ký hiệu 1A úp xuống bàn | 0,55 |
| `phim_2B.stl` | Mặt có ký hiệu 2B úp xuống bàn | 0,55 |
| `phim_3C.stl` | Mặt có ký hiệu 3C úp xuống bàn | 0,55 |
| `phim_4D.stl` | Mặt có ký hiệu 4D úp xuống bàn | 0,55 |
| `phim_5.stl` | Mặt có ký hiệu 5 úp xuống bàn | 0,55 |
| `phim_6.stl` | Mặt có ký hiệu 6 úp xuống bàn | 0,55 |
| `phim_7.stl` | Mặt có ký hiệu 7 úp xuống bàn | 0,56 |
| `phim_8.stl` | Mặt có ký hiệu 8 úp xuống bàn | 0,55 |
| `phim_BACK.stl` | Mặt có ký hiệu ← úp xuống bàn | 0,56 |
| `phim_9.stl` | Mặt có ký hiệu 9 úp xuống bàn | 0,55 |
| `phim_0.stl` | Mặt có ký hiệu 0 úp xuống bàn | 0,55 |
| `phim_OK.stl` | Mặt có ký hiệu OK úp xuống bàn | 0,55 |

Tổng 44,2 cm³ khối đặc, tối đa khoảng 55 g PLA; in có độ đặc thì ít hơn.

- PLA hoặc PETG, đầu phun 0,4 mm, lớp 0,2 mm, **không cần support**.
- Vỏ trên, vỏ dưới: 3 đường thành, độ đặc 15–20 %.
- Nắp pin, nắp USB: độ đặc 100 % (lẫy 0,8 mm và chốt cần đặc). Muốn lẫy dẻo hơn thì in nắp pin bằng PETG.
- In thử trước nắp pin, nắp USB và 1 phím để xem độ khít trên máy in của bạn.

## Vật tư mua thêm

4 vít M2×20 đầu tròn, bộ tiếp điểm AAA (1 lá +, 1 lò xo −, 1 lá nối tiếp), 2 pin AAA, motor rung 0834,
mica đỏ 1,5 mm cắt 19,4 × 15,6 mm (không bắt buộc), dây mảnh 26–30 AWG. Chi tiết: `../../BOM.md`.

## Lắp ráp

1. Cắm module SuperMini vào socket J1/J2; cắt chân xuyên lỗ dưới board còn tối đa 3,8 mm.
2. Ấn lá + và lò xo − vào 2 hốc bên trái khoang pin, lá nối tiếp vào hốc bên phải; đặt motor vào ổ.
3. Hàn dây pin vào J4 (đỏ chân 2, đen chân 1 GND), dây motor vào J3; đặt board nằm phẳng trên nóc khoang pin.
4. Úp vỏ trên xuống bàn, thả 12 phím vào ống dẫn, đặt mica vào hốc cửa sổ LED; lật vỏ trên úp lên board.
5. Bắt 4 vít M2×20 từ đáy.
6. Ấn nắp USB vào hốc ở cạnh phải: 2 chốt bấm lọt qua khe, nắp trượt được nhưng không rơi.
7. Lắp 2 pin theo dấu + / − khắc trong nắp pin, ấn thẳng nắp vào tới khi nghe “tách”. Tháo: móng tay vào khe kéo, kéo thẳng ra.

## `step/`: mở trên SolidWorks

| File | Là gì |
|---|---|
| `student_tag_v2_vo-lap-rap.step` | Cả vỏ: 16 khối (vỏ trên, vỏ dưới, nắp pin, nắp USB, 12 phím), đã tô màu để dễ nhìn |
| `student_tag_v2_vo-tren.step`, `…_vo-duoi.step`, `…_nap-pin.step`, `…_nap-usb.step`, `…_phim.step` | Từng phần riêng |
| `student_tag_board_kicad.step` | Board và linh kiện, xuất từ KiCad (chưa có module SuperMini: KiCad không có mô hình của nó) |

- Mọi file dùng chung một gốc tọa độ: góc dưới trái của board (phía phím), X sang phải, Y về phía module,
  Z = 0 ở mặt dưới board, đơn vị mm, đúng vị trí khi lắp. Trong SolidWorks: tạo Assembly, Insert Component
  từng file, đặt tại gốc (Fix) là các phần khớp nhau.
- File vỏ là khối đặc (solid) ghép từ các mặt phẳng; mặt bo cong gồm nhiều mặt nhỏ. Đo, lắp ráp, ra bản vẽ được,
  nhưng không có lịch sử tính năng (feature tree). Muốn đổi kích thước thì sửa `student_tag_case_v2.scad` và
  chạy lại `export_v2.py`.

## Cần đo trên linh kiện thật trước khi in

| Thông số trong `.scad` | Đang dùng | Đo ở đâu |
|---|---|---|
| `sw_h` / `sw_travel` | 1,5 / 0,3 mm | Nút SKQG: cao từ mặt board tới đỉnh cần; nhấn bao sâu thì ăn |
| `socket_h` | 8,5 mm | Socket J1/J2: từ mặt board tới mặt dưới module |
| `contact_len` / `contact_t` / `plate_w` | 5,5 / 0,6 / 10 mm | Bộ tiếp điểm AAA mua về |
| `motor_d` | 8,2 mm | Motor rung 0834 |

Đổi số nào thì chạy lại `/usr/bin/python3 tests/case_test.py v2` (kiểm tra lắp ghép) rồi `export_v2.py`.
